//
// Created by or on 27/11/17.
//

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "../Board.h"


TEST(ClassDeclaration,PlayerTest){
    Board b=Board(8);
    EXPECT_EQ(b.getSizeOfArray(),10);
    b.deleteAll();

}