// or aharoni 208250746

#include <iostream>
#include "Board.h"
#include "malloc.h"
#include "Player.h"
#include "CellCollection.h"
#include "GameLogics.h"
#include "Winner.h"
#include "GameFlow.h"
#include <gtest/gtest.h>
#include <gmock/gmock.h>


using namespace std;


//int main(int argc,char* argv[]) {
  //GameFlow gameFlow=GameFlow();
    //gameFlow.run();


  ///  return 0;
//}